class Link(object): 
    crawled = False
    res_code = int
    extracted_links_count = int
    attempts = 0